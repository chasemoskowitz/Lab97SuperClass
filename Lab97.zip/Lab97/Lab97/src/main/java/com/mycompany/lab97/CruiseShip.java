//Chase Moskowitz
package com.mycompany.lab97;

public class CruiseShip extends Ship
{
    private int numPassengers;
    
    public CruiseShip (String newNameOfShip, String newYearBuilt,
                    int newNumPassengers)
    {
        super(newNameOfShip, newYearBuilt);
        numPassengers=newNumPassengers;
    }
    
    public int getNumPassengers()
    {
        return numPassengers;
    }
    public void setNumPassengers(int newNumPassengers)
    {
         numPassengers=newNumPassengers;
    }
    
     public String toString()
   {
       String str=null;
       
       // Create a string describing the stock.
       
         str = String.format("Ship: " + getShipName() +
                 " - # Passengers: " +numPassengers);
                   
      
        // Return the string.
        return str;
   }  
    
    
    
    
}

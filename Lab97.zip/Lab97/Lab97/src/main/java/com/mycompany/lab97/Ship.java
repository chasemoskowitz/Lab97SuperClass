//Chase Moskowitz
package com.mycompany.lab97;


public class Ship
{
    private String nameOfShip;
    private String yearBuilt;
    
    public Ship (String newNameOfShip, String newYearBuilt)
    {
        nameOfShip=newNameOfShip;
        yearBuilt=newYearBuilt;
    }
    
    public String getShipName()
    {
        return nameOfShip;
    }
    
    public String getYearBuilt()
    {
        return yearBuilt;
    }
    
    public void setShipName(String newNameOfShip)
    {
       nameOfShip=newNameOfShip;
    }
    
    public void setYearBuilt (String newYearBuilt)
    {
        yearBuilt=newYearBuilt;
    }
    
   public String toString()
   {
       String str=null;
       
       // Create a string describing the stock.
       
         str = String.format("Ship: " + nameOfShip + " - Built: " +yearBuilt);
                   
      
        // Return the string.
        return str;
   }  
    
}

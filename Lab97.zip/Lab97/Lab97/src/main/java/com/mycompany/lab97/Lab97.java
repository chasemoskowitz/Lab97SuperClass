//Chase Moskowitz

package com.mycompany.lab97;


public class Lab97
{
    public static void main(String[] args)
    {
        int index=0;
        
         Ship shipArray[] =new Ship[5];
         shipArray[0]=new CruiseShip("SS Minow", "0", 7);
         shipArray[1]=new CruiseShip("Titanic", "0", 3327);
         shipArray[2]=new CargoShip("Maersk Alabama", "0", 14120);
         shipArray[3]=new CruiseShip("Costa Concordia", "0", 3780);
         shipArray[4]=new Ship("Black Pearl", "1725");
         
         for (index=0; index<shipArray.length; index++)
         {
             System.out.printf("%d %s\n", index, shipArray[index]);
         }
    }
}
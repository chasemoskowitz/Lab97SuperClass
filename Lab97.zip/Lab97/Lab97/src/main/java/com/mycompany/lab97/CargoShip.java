package com.mycompany.lab97;

public class CargoShip extends Ship
{
    private int cargoCap;
    
    public CargoShip (String newNameOfShip, String newYearBuilt,
            int newCargoCap)
    {
        super(newNameOfShip, newYearBuilt);
        cargoCap=newCargoCap;
    }
    
    public int getCargoCap()
    {
        return cargoCap;
    }
    
    public void setCargoCap(int newCargoCap)
    {
        cargoCap=newCargoCap;
    }
    public String toString()
   {
       String str=null;
       
       // Create a string describing the stock.
       
         str = String.format("Ship: " + getShipName() +
                 " - # Tonnage: " +cargoCap);
                   
      
        // Return the string.
        return str;
   }  
    
}
